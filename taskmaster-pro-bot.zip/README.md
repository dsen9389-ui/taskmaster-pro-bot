# TaskMaster Pro Bot

Production-ready Telegram productivity bot built with Python 3.11 and aiogram 3.x.

## Features
- Async SQLite database integration
- Modular router architecture
- Comprehensive error handling and graceful shutdown

## Local Setup
1. Clone the repository
2. Copy `.env.example` to `.env` and fill in your `BOT_TOKEN`
3. Install dependencies: `pip install -r requirements.txt`
4. Run the bot: `python main.py`

## Deployment (Render / Koyeb)
- Create a new Web Service or Background Worker
- Set the build command: `pip install -r requirements.txt`
- Set the start command: `python main.py`
- Add environment variable `BOT_TOKEN`